"""
------------------------------------------------------------------------
[Assignment 1, Task 2]
------------------------------------------------------------------------
Author: Rein Lumbres
ID:     169064888
Email:  lumb4888@wlu.ca
__updated__ = "2024-01-13"
------------------------------------------------------------------------
"""
from functions import list_subtraction

minuend = [5, 5, 4, 5]
subtrahend = [5]

list_subtraction(minuend, subtrahend)

print(minuend)