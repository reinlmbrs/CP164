"""
------------------------------------------------------------------------
[Assignment 1, Task 6]
------------------------------------------------------------------------
Author: Rein Lumbres
ID:     169064888
Email:  lumb4888@wlu.ca
__updated__ = "2024-01-14"
------------------------------------------------------------------------
"""
from functions import is_valid

name = input("Python variable name: ")

valid = is_valid(name)

print(valid)