"""
------------------------------------------------------------------------
[Assignment 1, Task 4]
------------------------------------------------------------------------
Author: Rein Lumbres
ID:     169064888
Email:  lumb4888@wlu.ca
__updated__ = "2024-01-13"
------------------------------------------------------------------------
"""

from functions import file_analyze

filename = "file.txt"
with open (filename, 'r') as fv: 
    upp, low, dig, whi, rem = file_analyze(fv)
print(upp, low, dig, whi, rem)