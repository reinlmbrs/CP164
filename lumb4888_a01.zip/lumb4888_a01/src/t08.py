"""
------------------------------------------------------------------------
[Assignment 1, Task 8]
------------------------------------------------------------------------
Author: Rein Lumbres
ID:     169064888
Email:  lumb4888@wlu.ca
__updated__ = "2024-01-14"
------------------------------------------------------------------------
"""
from functions import matrix_stats

a = [
    [1, 3, 5],
    [5, 100, 6],
    [24, 90, 33]
    ]

small, large, total, average = matrix_stats(a)

print(small, large, total, average)