"""
------------------------------------------------------------------------
[Assignment 1, Task 3]
------------------------------------------------------------------------
Author: Rein Lumbres
ID:     169064888
Email:  lumb4888@wlu.ca
__updated__ = "2024-01-13"
------------------------------------------------------------------------
"""

from functions import dsmvwl

string = input("String: ")

out = dsmvwl(string)

print(out)