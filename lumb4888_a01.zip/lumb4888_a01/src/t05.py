"""
------------------------------------------------------------------------
[Assignment 1, Task 5]
------------------------------------------------------------------------
Author: Rein Lumbres
ID:     169064888
Email:  lumb4888@wlu.ca
__updated__ = "2024-01-14"
------------------------------------------------------------------------
"""
from functions import is_leap_year

year = int(input("Year: "))
if year < 0:
    print("Year must be greater than 0")
    
    
leap_year = is_leap_year(year)
print(leap_year)