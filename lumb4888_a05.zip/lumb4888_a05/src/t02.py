"""
------------------------------------------------------------------------
[Assignment 5, Task 2]
------------------------------------------------------------------------
Author: Rein Lumbres
ID:     169064888
Email:  lumb4888@wlu.ca
__updated__ = "2024-02-10"
------------------------------------------------------------------------
"""
from Sorted_List_array import Sorted_List

# __contains__
foods = ["banana", "apple", "grape", "strawberry", "orange"]
print(3 in foods)
print()

# __eq__
food1 = Sorted_List()
food2 = Sorted_List()
food3 = Sorted_List()

food1._values = [1, 2, 3]
food2._values = [3, 2, 1]
food3._values = [1, 2, 3]

print(food1 == food2)
print(food1 == food3)
print()

# __getitem__
food = Sorted_List()
food._values = ["banana", "apple", "grape", "strawberry", "orange"]
print(f"Get Item: {food._values[2]}")
print()

# clean
food = Sorted_List()
food._values = ["banana", "apple", "grape", "apple", "apple"]
print(f"List: {food._values}")

food.clean()
print(f"Cleaned list: {food._values}")
print()

# count
food = Sorted_List()
food._values = ["apple", "apple", "grape", "strawberry", "orange"]

key = "apple"

count = food._values.count(key)

print(f"{key} appears in the list {count} times")
print()

# find -- FIX!
food = Sorted_List()
food._values = ["apple", "apple", "grape", "strawberry", "orange"]

key = "apple"
print(food.find(key)) 

key = "lettuce"
print(food.find(key)) 
print()

# index
values = Sorted_List()
values._value = ["apple", "banana", "grape", "strawberry", "orange"]

key = "banana"
print(values.index(key)) 


print(values.index(6))
print()

# intersection
food1 = Sorted_List()
food2 = Sorted_List()
result = Sorted_List()

food1 = ["banana", "apple", "grape", "orange", "tomato", "lettuce"]
food2 = ["tomato", "lettuce", "broccoli", "carrot", "banana", "apple"]

result.intersection(food1, food2)


print(result._values)
print()

# max
source = Sorted_List()
source._values = [10, 50, 100, 1000]

source.max()
print(f"Maximum value in source: {source.max()}")
print()

# min
source = Sorted_List()
source._values = [10, 50, 100, 1000]

source.min()
print(f"Minimum value in source: {source.min()}")
print()

# peek
source = Sorted_List()
source._values = ["banana", "apple", "grape"]

value = source.peek()

print(f"Peek value: {value}")
print()

# remove
food = Sorted_List()
food._values = ["apple", "banana", "grape", "strawberry", "orange"]

key = "strawberry"
value = food.remove(key)

print(value) 
print()

# remove_front
source = Sorted_List()
source._values = ["apple", "banana", "grape", "strawberry", "orange"]


removed_value = source.remove_front()

print("Value removed:", removed_value)
print("New list:", source._values)
print()

# remove_many
foods = Sorted_List()
foods._values = ["apple", "banana", "grape", "strawberry", "orange"]

foods.remove_many("strawberry")

print(f"Updated list: {foods._values}")
print()

# split
foods = Sorted_List()
foods._values = ["banana", "apple", "grape", "orange", "strawberry"]

target1, target2 = foods.split()

print(f"Left: {target1._values}")  
print(f"Right: {target2._values}")   
print(f"Updated source: {foods._values})")
print() 

# split_alt
foods = Sorted_List()
foods._values = ["banana", "apple", "grape", "orange", "strawberry", "tomato", "lettuce", "broccoli", "carrot", "corn"]

target1, target2 = foods.split_alt()

print(f"Target 1 (even): {target1._values}")  
print(f"Target 2 (odd): {target2._values}") 
print(foods._values) 
print()

# split_key
foods = Sorted_List()
foods._values = ["apple", "banana", "grape", "strawberry", "orange"]

target1, target2 = source.split_key("grape")
print(target1._values)  
print(target2._values)  
print()

# union 
foods = Sorted_List()
foods._values = ["banana", "apple", "grape", "strawberry"]

source1 = Sorted_List()
source1._values = ["orange", "strawberry", "tomato", "banana"]

source2 = Sorted_List()
source2._values = ["lettuce", "broccoli", "carrot", "banana"]

foods.union(source1, source2)

print(foods._values) 




