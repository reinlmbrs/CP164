"""
------------------------------------------------------------------------
[Assignment 5, Task 1]
------------------------------------------------------------------------
Author: Rein Lumbres
ID:     169064888
Email:  lumb4888@wlu.ca
__updated__ = "2024-02-10"
------------------------------------------------------------------------
"""
from List_array import List

# __eq__
foods = ["banana", "apple", "grape", "orange"]
list1 = List()
list2 = List()
list3 = List()
list4 = List()

list1.append(foods[1])
list2.append(foods[1])

list3.append(foods[0])
list4.append(foods[3])

print("List 1 = List 2?", list1 == list2)
print("List 3 = List 4?", list3 == list4)
print()

# __getitem__
foods = ["banana", "apple", "grape", "orange"]

if len(foods) != 0:
    print("Get Item:", foods[1])
    print()
    
# clean
foods = ["banana", "apple", "grape", "orange", "banana", "apple"]
print(foods)

foods = list(set(foods))
print(f"Cleaned: {foods}")
print()

# combine
list5 = List()
food1 = ["banana", "apple", "grape", "orange"]
food2 = ["tomato", "lettuce", "broccoli", "carrot"]

list5.combine(food1, food2)

print("Combined list:", list5._values)
print()

# intersection
list6 = List()
food1 = ["banana", "apple", "grape", "orange", "tomato", "lettuce"]
food2 = ["tomato", "lettuce", "broccoli", "carrot", "banana", "apple"]

list6.intersection(food1, food2)

print(f"Food that appears in both lists: {list6._values}")
print()

# prepend
foods = List()
foods.prepend("strawberry")
foods.prepend("orange")

print(f"List prepended: {foods._values}")
print()

# remove_front
foods = List()
foods._values = ["strawberry", "apple", "grape", "orange", "banana", "apple"]

remove_food = foods.remove_front()

print(f"Item Removed: {remove_food}")
print(f"Updated List: {foods._values}") 
print()

# remove_many
foods = List()
foods._values = ["strawberry", "banana", "strawberry", "orange", "apple", "strawberry"]

foods.remove_many("strawberry")

print(f"Updated list: {foods._values}")
print()

# split
foods = List()
foods._values = ["banana", "apple", "grape", "orange", "strawberry"]

target1, target2 = foods.split()

print(f"Left: {target1._values}")  
print(f"Right: {target2._values}")   
print(f"Updated source: {foods._values})") 
print()

# split_alt
foods = List()
foods._values = ["banana", "apple", "grape", "orange", "strawberry", "tomato", "lettuce", "broccoli", "carrot", "corn"]

target1, target2 = foods.split_alt()

print(target1._values)  
print(target2._values) 
print(foods._values) 
print()

# union
foods = List()
foods._values = ["banana", "apple", "grape", "strawberry"]

source1 = List()
source1._values = ["orange", "strawberry", "tomato", "banana"]

source2 = List()
source2._values = ["lettuce", "broccoli", "carrot", "banana"]

foods.union(source1, source2)
print(foods._values) 
