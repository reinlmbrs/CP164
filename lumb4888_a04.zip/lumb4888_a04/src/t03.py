"""
------------------------------------------------------------------------
[Assignment 4, Task 3]
------------------------------------------------------------------------
Author: Rein Lumbres
ID:     169064888
Email:  lumb4888@wlu.ca
__updated__ = "2024-02-03"
------------------------------------------------------------------------
"""
from functions import queue_split_alt
from Queue_circular import Queue

source = Queue()


for value in range(50):
    source.insert(value)

target1, target2 = queue_split_alt(source)

print(f"Target 1: {target1}")
print(f"Target 2: {target2}")
print(f"Source: {source}")

