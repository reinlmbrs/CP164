"""
------------------------------------------------------------------------
[Assignment 4, Task 4]
------------------------------------------------------------------------
Author: Rein Lumbres
ID:     169064888
Email:  lumb4888@wlu.ca
__updated__ = "2024-02-03"
------------------------------------------------------------------------
"""
from Queue_array import Queue

source = Queue()

for i in range(5):
    source.insert(i)


target1, target2 = source.split_alt()


while not target1.is_empty():
    print(target1.insert(), end =" ")
print()

while not target2.is_empty():
    print(target2.insert(), end =" ")
print()

