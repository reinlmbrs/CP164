"""
------------------------------------------------------------------------
[Assignment 4, Task 1]
------------------------------------------------------------------------
Author: Rein Lumbres
ID:     169064888
Email:  lumb4888@wlu.ca
__updated__ = "2024-02-03"
------------------------------------------------------------------------
"""
from Queue_circular import Queue

queue = Queue()

for i in range(10):
    queue.insert(i)

if queue.is_full():
    print("Queue is full")
else:
    print("Queue is not full")
    
if queue.is_empty():
    print("Queue is empty")
else:
    print("Queue is not empty")


value = queue.peek()
print(f"First in Queue: {value}")

remove_value = queue.remove()
print(f"Removed: {remove_value} from queue")

print(f"In queue: {len(queue)}")

second_queue = Queue()
for i in range(10):
    second_queue.insert(i)

if queue == second_queue:
    print("Queue 1 = Queue 2")
else:
    print("Queues are not equal.")

print("The queue:")
for value in queue:
    print(value)