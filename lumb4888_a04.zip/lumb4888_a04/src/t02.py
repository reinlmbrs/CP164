"""
------------------------------------------------------------------------
[Assignment 4, Task 2]
------------------------------------------------------------------------
Author: Rein Lumbres
ID:     169064888
Email:  lumb4888@wlu.ca
__updated__ = "2024-02-03"
------------------------------------------------------------------------
"""
from Queue_circular import Queue

queue1 = Queue()
queue2 = Queue()

for value in [1,2,3,4,5,6,7,8,9]:
    queue1.insert(value)
    queue2.insert(value)
    
if queue1.__eq__(queue2):
    print("The queues are equal.")
else:
    print("The queues are not equal.")