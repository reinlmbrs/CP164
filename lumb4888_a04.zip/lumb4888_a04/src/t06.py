"""
------------------------------------------------------------------------
[Assignment 4, Task 6]
------------------------------------------------------------------------
Author: Rein Lumbres
ID:     169064888
Email:  lumb4888@wlu.ca
__updated__ = "2024-02-03"
------------------------------------------------------------------------
"""
from Priority_Queue_array import Priority_Queue

source = Priority_Queue()
for i in range(1,20):
    source.insert(i)

key = 10

target1, target2 = source.split_key(key)

print("Priority Queue:")
for i in source:
    print(i, end=" ")

print("Values higher than key:")
for i in target1:
    print(i, end=' ')
print()

print("Lower/Equal than key:")
for i in target2:
    print(i, end=' ')
print()