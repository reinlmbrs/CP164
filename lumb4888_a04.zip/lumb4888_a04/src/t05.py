"""
------------------------------------------------------------------------
[Assignment 4, Task 5]
------------------------------------------------------------------------
Author: Rein Lumbres
ID:     169064888
Email:  lumb4888@wlu.ca
__updated__ = "2024-02-03"
------------------------------------------------------------------------
"""
from Priority_Queue_array import Priority_Queue
from functions import pq_split_key

source = Priority_Queue()

for i in range(1,50):
    source.insert(i)

key = 25

target1, target2 = pq_split_key(source, key)

print("Target 1:")
for value in target1:
    print(value, end=" ")
print()

print("Target 1:")
for value in target2:
    print(value, end=" ")
print()