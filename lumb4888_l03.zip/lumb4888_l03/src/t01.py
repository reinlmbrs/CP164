"""
------------------------------------------------------------------------
[Lab 3, Task 1]
------------------------------------------------------------------------
Author: Rein Lumbres
ID:     169064888
Email:  lumb4888@wlu.ca
__updated__ = "2024-01-26"
------------------------------------------------------------------------
"""
from Queue_array import Queue

q = Queue()

values = [10]

for i in values:
    print(f"Inserting {values} in queue")
    q.insert(values)
    print(f"Queue: {[value for value in q]}")
    

