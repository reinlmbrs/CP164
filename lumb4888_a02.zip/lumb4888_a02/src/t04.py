"""
------------------------------------------------------------------------
[Assignment 2, Task 4]
------------------------------------------------------------------------
Author: Rein Lumbres
ID:     169064888
Email:  lumb4888@wlu.ca
__updated__ = "2024-01-21"
------------------------------------------------------------------------
"""
from Food_utilities import food_table
from Food import Food

food1 = Food("Lasagna", 7, False, 135)
food2 = Food("Teppanyaki", 6, False, 200)
food3 = Food("Fettuccine", 7, False, 266)
foods = [food1, food2, food3]

food_table(foods)