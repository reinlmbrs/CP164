"""
------------------------------------------------------------------------
[Lab 2, Task 1]
------------------------------------------------------------------------
Author: Rein Lumbres
ID:     169064888
Email:  lumb4888@wlu.ca
__updated__ = "2024-01-18"
------------------------------------------------------------------------
"""

from Stack_array import Stack

s = Stack()

print(f"Is stack empty? {s.is_empty()}")

s.push(10)
s.push(50)
s.push(100)

print(f"Is stack still empty? {s.is_empty()}")

peek = s.peek()
print(peek)

pop = s.pop()
print(pop)

new_value = s.peek()
print(new_value)