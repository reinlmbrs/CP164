"""
------------------------------------------------------------------------
[Lab 9, Task 1]
------------------------------------------------------------------------
Author: Rein Lumbres
ID:     169064888
Email:  lumb4888@wlu.ca
__updated__ = "2024-03-16"
------------------------------------------------------------------------
"""
from Food import Food
from Hash_Set_array import Hash_Set
from functions import hash_table

slots = 7
values = [
    Food("Salad", 6, True, 100),
    Food("Poutine", 0, True, 245),
    Food("Apple", 4, True, 85)
    ]


hash_table(slots, values)